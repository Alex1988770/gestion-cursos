package com.cesde.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Docente {
    
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "docente_seq")
@SequenceGenerator(name = "docente_seq", sequenceName = "docente_seq", allocationSize = 1)
private Long id;


    private String nombre;
    private String documento;
    private String correo;
}
