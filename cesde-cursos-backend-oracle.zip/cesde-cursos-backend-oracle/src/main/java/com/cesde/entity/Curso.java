package com.cesde.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Curso {
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "curso_seq")
    @SequenceGenerator(name = "curso_seq", sequenceName = "curso_seq", allocationSize = 1)
    private Long id;
    

    private String nombre;
    private String descripcion;
    private int duracion;
    private double precio;
    private LocalDateTime fechaInicio;

    @ManyToOne
    private Docente docente;
}
