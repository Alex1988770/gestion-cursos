package com.cesde.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CursoDTO {
    private String nombre;
    private String descripcion;
    private int duracion;
    private double precio;
    private LocalDateTime fechaInicio;
    private Long docenteId;
}
