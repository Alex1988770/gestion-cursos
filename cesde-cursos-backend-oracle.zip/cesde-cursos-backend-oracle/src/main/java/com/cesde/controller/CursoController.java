package com.cesde.controller;

import com.cesde.dto.CursoDTO;
import com.cesde.entity.Curso;
import com.cesde.service.CursoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
@RequiredArgsConstructor
@CrossOrigin
public class CursoController {
    private final CursoService cursoService;

    @GetMapping
    public List<Curso> listar() {
        return cursoService.listar();
    }

    @PostMapping
    public Curso crear(@RequestBody CursoDTO dto) {
        return cursoService.crear(dto);
    }
}
