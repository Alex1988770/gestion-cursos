package com.cesde.controller;

import com.cesde.entity.Docente;
import com.cesde.repository.DocenteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/docentes")
@RequiredArgsConstructor
@CrossOrigin
public class DocenteController {
    private final DocenteRepository docenteRepo;

    @GetMapping
    public List<Docente> listar() {
        return docenteRepo.findAll();
    }

    @PostMapping
    public Docente guardar(@RequestBody Docente docente) {
        return docenteRepo.save(docente);
    }
}
