package com.cesde;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CesdeApplication {
    public static void main(String[] args) {
        SpringApplication.run(CesdeApplication.class, args);
    }
}
