package com.cesde.service;

import com.cesde.dto.CursoDTO;
import com.cesde.entity.Curso;
import com.cesde.entity.Docente;
import com.cesde.repository.CursoRepository;
import com.cesde.repository.DocenteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CursoService {
    private final CursoRepository cursoRepo;
    private final DocenteRepository docenteRepo;

    public List<Curso> listar() {
        return cursoRepo.findAll();
    }

    public Curso crear(CursoDTO dto) {
        Docente docente = docenteRepo.findById(dto.getDocenteId()).orElseThrow();
        Curso curso = new Curso(null, dto.getNombre(), dto.getDescripcion(), dto.getDuracion(),
                dto.getPrecio(), dto.getFechaInicio(), docente);
        return cursoRepo.save(curso);
    }
}
