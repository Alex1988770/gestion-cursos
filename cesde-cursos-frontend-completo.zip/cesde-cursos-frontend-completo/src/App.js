import React, { useEffect, useState } from "react";
import axios from "./axios";
import { useForm } from "react-hook-form";

function App() {
  const [cursos, setCursos] = useState([]);
  const [docentes, setDocentes] = useState([]);
  const [filtroNombre, setFiltroNombre] = useState("");
  const [filtroDuracion, setFiltroDuracion] = useState("");
  const [filtroDocente, setFiltroDocente] = useState("");

  const { register, handleSubmit, reset } = useForm();
  const { register: registerDocente, handleSubmit: handleDocenteSubmit, reset: resetDocente } = useForm();

  const fetchData = () => {
    axios.get("/cursos").then(res => setCursos(res.data));
    axios.get("/docentes").then(res => setDocentes(res.data));
  };

  useEffect(() => {
    fetchData();
  }, []);

  const onSubmitCurso = (data) => {
    data.duracion = parseInt(data.duracion);
    data.precio = parseFloat(data.precio);
    data.docenteId = parseInt(data.docenteId);
    data.fechaInicio = new Date().toISOString();
    axios.post("/cursos", data).then(() => {
      fetchData();
      reset();
    });
  };

  const onSubmitDocente = (data) => {
    axios.post("/docentes", data).then(() => {
      fetchData();
      resetDocente();
    });
  };

  const cursosFiltrados = cursos.filter(c =>
    c.nombre.toLowerCase().includes(filtroNombre.toLowerCase()) &&
    (filtroDuracion ? c.duracion === parseInt(filtroDuracion) : true) &&
    (filtroDocente ? c.docente?.nombre?.toLowerCase().includes(filtroDocente.toLowerCase()) : true)
  );

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold">Gestión de Cursos CESDE</h1>

      <section className="space-y-2">
        <h2 className="text-xl font-semibold">🎓 Crear nuevo curso</h2>
        <form onSubmit={handleSubmit(onSubmitCurso)} className="grid grid-cols-2 gap-2">
          <input {...register("nombre")} placeholder="Nombre del curso" className="border p-2" required />
          <input {...register("descripcion")} placeholder="Descripción" className="border p-2" required />
          <input type="number" {...register("duracion")} placeholder="Duración (semanas)" className="border p-2" required />
          <input type="number" step="0.01" {...register("precio")} placeholder="Precio" className="border p-2" required />
          <select {...register("docenteId")} className="border p-2" required>
            <option value="">Seleccionar docente</option>
            {docentes.map(d => (
              <option key={d.id} value={d.id}>{d.nombre}</option>
            ))}
          </select>
          <button className="bg-blue-500 text-white p-2 rounded col-span-2">Crear curso</button>
        </form>
      </section>

      <section className="space-y-2">
        <h2 className="text-xl font-semibold">👨‍🏫 Registrar docente</h2>
        <form onSubmit={handleDocenteSubmit(onSubmitDocente)} className="flex flex-wrap gap-2">
          <input {...registerDocente("nombre")} placeholder="Nombre" className="border p-2" required />
          <input {...registerDocente("documento")} placeholder="Documento" className="border p-2" required />
          <input {...registerDocente("correo")} placeholder="Correo" className="border p-2" required />
          <button className="bg-green-600 text-white p-2 rounded">Registrar</button>
        </form>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-2">📚 Listado de cursos</h2>
        <div className="flex gap-2 mb-4">
          <input placeholder="Filtrar por nombre" className="border p-1" value={filtroNombre} onChange={e => setFiltroNombre(e.target.value)} />
          <input placeholder="Filtrar por duración" type="number" className="border p-1" value={filtroDuracion} onChange={e => setFiltroDuracion(e.target.value)} />
          <input placeholder="Filtrar por docente" className="border p-1" value={filtroDocente} onChange={e => setFiltroDocente(e.target.value)} />
        </div>
        <ul className="list-disc pl-5 space-y-1">
          {cursosFiltrados.map(curso => (
            <li key={curso.id}>
              <strong>{curso.nombre}</strong> ({curso.duracion} semanas) — {curso.docente?.nombre ?? "Sin docente"} — 💰 ${curso.precio}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

export default App;
